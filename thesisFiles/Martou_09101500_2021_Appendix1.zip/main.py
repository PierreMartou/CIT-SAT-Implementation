from CITSAT import CITSAT
from ResultRefining import printCoveringArray
from UnifiedModel import SystemData
import time

"""Uses CITSAT() and displays the results.
"""
def testCITSATData():
    s = SystemData('contexts.txt', 'features.txt', 'mapping.txt')
    result = CITSAT(s, False)
    printCoveringArray(result, s, False)
    print("================================REFINED MODE=====================================")
    printCoveringArray(result, s, True)

def singleRun():
    time1 = time.time()
    s = SystemData('contexts.txt', 'features.txt', 'mapping.txt')
    result = CITSAT(s, False)
    printCoveringArray(result, s, False)
    print("================================REFINED MODE=====================================")
    printCoveringArray(result, s, True)
    totalTime = time.time() - time1
    print("Computation time : " + str(totalTime) + " seconds")


def multipleRuns(iterations):
    maxTime = 0
    minTime = 10000
    sumTime = 0
    iterations = 1
    for i in range(iterations):
        time1 = time.process_time()
        testCITSATData()
        totalTime = time.process_time() - time1
        maxTime = max(totalTime, maxTime)
        minTime = min(totalTime, minTime)
        sumTime += totalTime
        print(str(i) + "nth iteration. Computation took " + str(totalTime) + " seconds.")

    print("We took " + str(sumTime) + " seconds to compute " + str(iterations) + ".")
    print("The maximum time is " + str(maxTime) + " seconds.")
    print("The minimum time is " + str(minTime) + " seconds.")

def thesisExample():
    example = {}
    example['Brand'] = ['Nokia', 'Samsung']
    example['State'] = ['Broken', 'Used', 'New']
    example['Performance'] = ['Slow', 'Fast']
    result = CITSAT(None, example, False)
    for testCase in result:
        print(testCase)


singleRun() # Runs a single time the algorithm and displays the results

# multipleRuns(3) # Runs multiple times the algorithm, in order to obtain the average computation time

# thesisExample() # To illustrate covering array, we used this example