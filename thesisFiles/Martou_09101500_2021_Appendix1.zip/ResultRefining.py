
"""Refines the received array. SystemData is used to retrieve the list of contexts/features.
If refinedMode is False, will return a semi-refined array.
If refinedMode is True, will refine the completely refined array.
"""
def printCoveringArray(arrayCopy, systemData, refinedMode=False):
    print("========== RESULTS =============")
    if len(arrayCopy) == 0:
        print('No test case found.')
        return
    array = arrayCopy.copy()
    features = systemData.getFeatures()
    contexts = systemData.getContexts()
    array = orderArray(array, contexts)
    coreContexts = systemData.getContexts()
    coreFeatures = systemData.getFeatures()

    for testCase in array:
        for c in coreContexts:
            if testCase[c] < 0:
                coreContexts.remove(c)
        for f in coreFeatures:
            if testCase[f] < 0:
                coreFeatures.remove(f)
    print('CORE CONTEXTS : ' + str(coreContexts))
    print('CORE FEATURES : ' + str(coreFeatures))
    cores = coreFeatures + coreContexts + ['TreeRoot']

    nTest = 1
    if not refinedMode:
        for testCase in array:
            newLine = str(nTest) + ' ||| CONTEXTS : '
            newLine += str([context for context in testCase if testCase[context] > 0 and context not in cores and context in contexts])
            newLine += '\n  ||| FEATURES : '
            newLine += str([feature for feature in testCase if testCase[feature] > 0 and feature not in cores and feature in features])
            print(newLine)
            print('---------------------------------------------------------------------------------------------------------')
            nTest += 1
    else:
        prevTestCase = array[0]
        newLine = str(nTest) + ' ||| CONTEXTS : '
        newLine += str([context for context in prevTestCase if prevTestCase[context] > 0 and context not in cores and context in contexts])
        newLine += '\n  ||| FEATURES : '
        newLine += str([feature for feature in prevTestCase if prevTestCase[feature] > 0 and feature not in cores and feature in features])
        print(newLine)
        print('---------------------------------------------------------------------------------------------------------')
        nTest += 1
        for testCase in array[1:]:
            newLine = str(nTest) + ' || DELETED CONTEXTS : '
            newLine += str([context for context in testCase if testCase[context] < 0 and context in contexts and prevTestCase[context] > 0])
            newLine += '\n  || ADDED CONTEXTS : '
            newLine += str([context for context in testCase if
                            testCase[context] > 0 and context in contexts and prevTestCase[context] < 0])
            newLine += '\n  || DELETED FEATURES : '
            newLine += str([feature for feature in testCase if
                            testCase[feature] < 0 and feature in features and prevTestCase[feature] > 0])
            newLine += '\n  || ADDED FEATURES : '
            newLine += str([feature for feature in testCase if
                            testCase[feature] > 0 and feature in features and prevTestCase[feature] < 0])
            print(newLine)
            print('---------------------------------------------------------------------------------------------------------')
            nTest += 1
            prevTestCase = testCase

""" Sorts the array thanks to the distance definition in testDistance.
"""
def orderArray(array, nodes):
    prevTest = min(array, key=lambda testCase: sum([testCase[c] for c in nodes]))
    newArray = [prevTest]
    array.remove(prevTest)
    while array:  # until all test cases are transferred
        prevTest = min(array, key=lambda testCase: testDistance(testCase, prevTest, nodes))
        newArray.append(prevTest)
        array.remove(prevTest)
    return newArray
    # array = sorted(array, key=lambda testCase: testCaseDistance(testCase, initialTest))

"""Returns the distance between t1 and t2, only for features/contexts contained in nodes.
"""
def testDistance(t1, t2, nodes=None):
    distance = 0
    for node in t1:
        if t1[node] != t2[node]:
            if nodes is None or node in nodes:
                distance += 1
    return distance


def parentConstraint(constraints, root):
    concernedConstraints = []
    for constraint in constraints:
        (_, p, _) = constraint
        if p == root:
            concernedConstraints.append(constraint)
    if len(concernedConstraints) == 0:
        return None
    return concernedConstraints